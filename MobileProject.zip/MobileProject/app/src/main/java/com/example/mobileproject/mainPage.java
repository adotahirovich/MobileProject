package com.example.mobileproject;

public class mainPage {
}
